# OndcProtocolApiForRetailGroceryFb.OnSelectMessageOrder

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**provider** | [**Provider**](Provider.md) |  | [optional] 
**providerLocation** | [**Location**](Location.md) |  | [optional] 
**items** | **[AllOfonSelectMessageOrderItemsItems]** |  | [optional] 
**addOns** | [**[AddOn]**](AddOn.md) |  | [optional] 
**offers** | [**[Offer]**](Offer.md) |  | [optional] 
**quote** | [**Quotation**](Quotation.md) |  | [optional] 
