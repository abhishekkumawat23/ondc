# OndcProtocolApiForRetailGroceryFb.CancelBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**context** | [**Context**](Context.md) |  | 
**message** | [**CancelMessage**](CancelMessage.md) |  | 
