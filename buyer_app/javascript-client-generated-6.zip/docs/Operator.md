# OndcProtocolApiForRetailGroceryFb.Operator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**experience** | [**OperatorExperience**](OperatorExperience.md) |  | [optional] 
