# OndcProtocolApiForRetailGroceryFb.TimeRange

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**start** | **Date** |  | [optional] 
**end** | **Date** |  | [optional] 
