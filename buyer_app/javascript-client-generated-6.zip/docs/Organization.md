# OndcProtocolApiForRetailGroceryFb.Organization

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**cred** | **String** |  | [optional] 
