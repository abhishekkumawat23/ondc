# OndcProtocolApiForRetailGroceryFb.ScalarRange

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**min** | **Number** |  | [optional] 
**max** | **Number** |  | [optional] 
