# OndcProtocolApiForRetailGroceryFb.FeedbackUrlFeedbackId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
