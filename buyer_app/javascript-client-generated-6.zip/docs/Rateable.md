# OndcProtocolApiForRetailGroceryFb.Rateable

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
