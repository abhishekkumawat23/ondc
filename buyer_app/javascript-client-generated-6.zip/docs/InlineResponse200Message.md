# OndcProtocolApiForRetailGroceryFb.InlineResponse200Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ack** | [**Ack**](Ack.md) |  | 
