# OndcProtocolApiForRetailGroceryFb.FeedbackForm

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
