# OndcProtocolApiForRetailGroceryFb.AddOn

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**AddOnId**](AddOnId.md) |  | [optional] 
**descriptor** | [**Descriptor**](Descriptor.md) |  | [optional] 
**price** | [**Price**](Price.md) |  | [optional] 
