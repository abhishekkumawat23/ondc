# OndcProtocolApiForRetailGroceryFb.SearchMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**intent** | [**Intent**](Intent.md) |  | [optional] 
