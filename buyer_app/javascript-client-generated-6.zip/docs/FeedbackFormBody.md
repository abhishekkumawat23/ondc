# OndcProtocolApiForRetailGroceryFb.FeedbackFormBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**context** | [**Context**](Context.md) |  | [optional] 
**message** | [**Feedback**](Feedback.md) |  | [optional] 
