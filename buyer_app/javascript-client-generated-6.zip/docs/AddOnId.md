# OndcProtocolApiForRetailGroceryFb.AddOnId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
