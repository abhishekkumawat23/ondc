# OndcProtocolApiForRetailGroceryFb.UpdateMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**updateTarget** | **String** | Comma separated values of order objects being updated. For example: &#x60;&#x60;&#x60;\&quot;update_target\&quot;:\&quot;item,billing,fulfillment\&quot;&#x60;&#x60;&#x60; | 
**order** | [**Order**](Order.md) |  | 
