# OndcProtocolApiForRetailGroceryFb.OnInitMessageOrder

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**provider** | [**OnInitMessageOrderProvider**](OnInitMessageOrderProvider.md) |  | [optional] 
**providerLocation** | [**OnInitMessageOrderProviderLocation**](OnInitMessageOrderProviderLocation.md) |  | [optional] 
**items** | [**[OnInitMessageOrderItems]**](OnInitMessageOrderItems.md) |  | [optional] 
**addOns** | [**[OnInitMessageOrderAddOns]**](OnInitMessageOrderAddOns.md) |  | [optional] 
**offers** | [**[OnInitMessageOrderOffers]**](OnInitMessageOrderOffers.md) |  | [optional] 
**billing** | [**Billing**](Billing.md) |  | [optional] 
**fulfillment** | [**Fulfillment**](Fulfillment.md) |  | [optional] 
**quote** | [**Quotation**](Quotation.md) |  | [optional] 
**payment** | [**Payment**](Payment.md) |  | [optional] 
