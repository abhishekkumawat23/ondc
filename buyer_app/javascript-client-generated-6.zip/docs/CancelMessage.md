# OndcProtocolApiForRetailGroceryFb.CancelMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderId** | [**OrderId**](OrderId.md) |  | 
**cancellationReasonId** | [**OptionId**](OptionId.md) |  | [optional] 
**descriptor** | [**Descriptor**](Descriptor.md) |  | [optional] 
