# OndcProtocolApiForRetailGroceryFb.OnSearchBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**context** | [**Context**](Context.md) |  | 
**message** | [**OnSearchMessage**](OnSearchMessage.md) |  | [optional] 
**error** | [**Error**](Error.md) |  | [optional] 
