# OndcProtocolApiForRetailGroceryFb.Descriptor

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**code** | **String** |  | [optional] 
**symbol** | **String** |  | [optional] 
**shortDesc** | **String** |  | [optional] 
**longDesc** | **String** |  | [optional] 
**images** | [**[Image]**](Image.md) |  | [optional] 
**audio** | **String** |  | [optional] 
**_3dRender** | **String** |  | [optional] 
