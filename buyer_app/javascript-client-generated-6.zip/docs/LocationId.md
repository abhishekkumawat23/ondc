# OndcProtocolApiForRetailGroceryFb.LocationId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
