# OndcProtocolApiForRetailGroceryFb.FeedbackUrlParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
