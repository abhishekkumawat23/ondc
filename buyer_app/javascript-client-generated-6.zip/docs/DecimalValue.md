# OndcProtocolApiForRetailGroceryFb.DecimalValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
