# OndcProtocolApiForRetailGroceryFb.CancellationSelectedReason

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**OptionId**](OptionId.md) |  | [optional] 
