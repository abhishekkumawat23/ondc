# OndcProtocolApiForRetailGroceryFb.SelectMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**order** | [**Order**](Order.md) |  | 
