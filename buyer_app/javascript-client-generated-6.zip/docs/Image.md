# OndcProtocolApiForRetailGroceryFb.Image

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
