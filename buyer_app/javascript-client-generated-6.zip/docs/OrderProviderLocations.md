# OndcProtocolApiForRetailGroceryFb.OrderProviderLocations

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**LocationId**](LocationId.md) |  | 
