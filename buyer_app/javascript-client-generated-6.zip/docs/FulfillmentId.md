# OndcProtocolApiForRetailGroceryFb.FulfillmentId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
