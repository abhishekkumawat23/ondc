# OndcProtocolApiForRetailGroceryFb.SupportMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**refId** | **String** | ID of the element for which support is needed | [optional] 
