# OndcProtocolApiForRetailGroceryFb.Circle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**gps** | [**Gps**](Gps.md) |  | 
**radius** | [**Scalar**](Scalar.md) |  | 
