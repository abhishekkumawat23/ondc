# OndcProtocolApiForRetailGroceryFb.ItemQuantity

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**allocated** | [**ItemQuantityAllocated**](ItemQuantityAllocated.md) |  | [optional] 
**available** | [**ItemQuantityAllocated**](ItemQuantityAllocated.md) |  | [optional] 
**maximum** | [**ItemQuantityMaximum**](ItemQuantityMaximum.md) |  | [optional] 
**minimum** | [**ItemQuantityAllocated**](ItemQuantityAllocated.md) |  | [optional] 
**selected** | [**ItemQuantityAllocated**](ItemQuantityAllocated.md) |  | [optional] 
