# OndcProtocolApiForRetailGroceryFb.AllOfonSelectMessageOrderItemsItems

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**quantity** | [**ItemQuantity**](ItemQuantity.md) |  | [optional] 
