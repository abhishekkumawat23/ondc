# OndcProtocolApiForRetailGroceryFb.OnSupportMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**phone** | **String** |  | [optional] 
**email** | **String** |  | [optional] 
**uri** | **String** |  | [optional] 
