# OndcProtocolApiForRetailGroceryFb.FulfillmentStart

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**location** | [**Location**](Location.md) |  | [optional] 
**time** | [**Time**](Time.md) |  | [optional] 
**instructions** | [**Descriptor**](Descriptor.md) |  | [optional] 
**contact** | [**Contact**](Contact.md) |  | [optional] 
**person** | [**Person**](Person.md) |  | [optional] 
**authorization** | [**Authorization**](Authorization.md) |  | [optional] 
