# OndcProtocolApiForRetailGroceryFb.Person

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | [**Name**](Name.md) |  | [optional] 
**image** | [**Image**](Image.md) |  | [optional] 
**dob** | **Date** |  | [optional] 
**gender** | **String** | Gender of something, typically a Person, but possibly also fictional characters, animals, etc. While Male and Female may be used, text strings are also acceptable for people who do not identify as a binary gender | [optional] 
**cred** | **String** |  | [optional] 
**tags** | [**Tags**](Tags.md) |  | [optional] 
