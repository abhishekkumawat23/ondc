# OndcProtocolApiForRetailGroceryFb.FulfillmentCustomer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**person** | [**Person**](Person.md) |  | [optional] 
**contact** | [**Contact**](Contact.md) |  | [optional] 
