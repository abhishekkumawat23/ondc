# OndcProtocolApiForRetailGroceryFb.RatingAck

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**feedbackAck** | **Boolean** | If feedback has been recorded or not | [optional] 
**ratingAck** | **Boolean** | If rating has been recorded or not | [optional] 
