# OndcProtocolApiForRetailGroceryFb.OnRatingBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**context** | [**Context**](Context.md) |  | 
**message** | [**RatingAck**](RatingAck.md) |  | [optional] 
**error** | [**Error**](Error.md) |  | [optional] 
