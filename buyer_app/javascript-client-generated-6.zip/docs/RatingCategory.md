# OndcProtocolApiForRetailGroceryFb.RatingCategory

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
