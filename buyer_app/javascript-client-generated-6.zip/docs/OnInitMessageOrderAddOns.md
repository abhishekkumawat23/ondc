# OndcProtocolApiForRetailGroceryFb.OnInitMessageOrderAddOns

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**AddOnId**](AddOnId.md) |  | [optional] 
