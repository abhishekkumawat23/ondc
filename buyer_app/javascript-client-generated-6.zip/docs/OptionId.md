# OndcProtocolApiForRetailGroceryFb.OptionId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
