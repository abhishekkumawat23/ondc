# OndcProtocolApiForRetailGroceryFb.CancellationReasonsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**context** | [**Context**](Context.md) |  | [optional] 
**message** | [**CancellationReasonsMessage**](CancellationReasonsMessage.md) |  | [optional] 
