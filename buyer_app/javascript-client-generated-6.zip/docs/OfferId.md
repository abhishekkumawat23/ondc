# OndcProtocolApiForRetailGroceryFb.OfferId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
