# OndcProtocolApiForRetailGroceryFb.PolicyId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
