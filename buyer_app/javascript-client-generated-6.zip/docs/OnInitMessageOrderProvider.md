# OndcProtocolApiForRetailGroceryFb.OnInitMessageOrderProvider

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**ProviderId**](ProviderId.md) |  | [optional] 
