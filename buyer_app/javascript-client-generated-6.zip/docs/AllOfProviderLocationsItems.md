# OndcProtocolApiForRetailGroceryFb.AllOfProviderLocationsItems

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rateable** | [**Rateable**](Rateable.md) |  | [optional] 
