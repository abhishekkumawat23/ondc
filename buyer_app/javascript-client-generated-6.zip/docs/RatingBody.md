# OndcProtocolApiForRetailGroceryFb.RatingBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**context** | [**Context**](Context.md) |  | 
**message** | [**Rating**](Rating.md) |  | 
