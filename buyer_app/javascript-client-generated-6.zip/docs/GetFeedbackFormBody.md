# OndcProtocolApiForRetailGroceryFb.GetFeedbackFormBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**context** | [**Context**](Context.md) |  | [optional] 
**message** | [**GetFeedbackFormMessage**](GetFeedbackFormMessage.md) |  | [optional] 
