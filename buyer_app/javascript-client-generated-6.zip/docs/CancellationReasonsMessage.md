# OndcProtocolApiForRetailGroceryFb.CancellationReasonsMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cancellationReasons** | [**[Option]**](Option.md) |  | [optional] 
