# OndcProtocolApiForRetailGroceryFb.OnInitMessageOrderItems

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**ItemId**](ItemId.md) |  | [optional] 
**quantity** | [**ItemQuantitypropertiesselected**](ItemQuantitypropertiesselected.md) |  | [optional] 
