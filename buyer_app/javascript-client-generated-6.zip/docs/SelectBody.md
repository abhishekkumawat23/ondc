# OndcProtocolApiForRetailGroceryFb.SelectBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**context** | [**Context**](Context.md) |  | 
**message** | [**SelectMessage**](SelectMessage.md) |  | 
