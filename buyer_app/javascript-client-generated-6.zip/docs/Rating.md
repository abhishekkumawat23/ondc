# OndcProtocolApiForRetailGroceryFb.Rating

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ratingCategory** | [**RatingCategory**](RatingCategory.md) |  | [optional] 
**id** | **String** | Id of the object being rated | [optional] 
**value** | [**RatingValue**](RatingValue.md) |  | [optional] 
**feedbackForm** | [**FeedbackForm**](FeedbackForm.md) |  | [optional] 
**feedbackId** | [**FeedbackUrlFeedbackId**](FeedbackUrlFeedbackId.md) |  | [optional] 
