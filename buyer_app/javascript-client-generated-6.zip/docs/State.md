# OndcProtocolApiForRetailGroceryFb.State

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**descriptor** | [**Descriptor**](Descriptor.md) |  | [optional] 
**updatedAt** | **Date** |  | [optional] 
**updatedBy** | **String** | ID of entity which changed the state | [optional] 
