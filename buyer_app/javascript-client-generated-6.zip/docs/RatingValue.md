# OndcProtocolApiForRetailGroceryFb.RatingValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
