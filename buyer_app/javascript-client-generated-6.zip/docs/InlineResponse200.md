# OndcProtocolApiForRetailGroceryFb.InlineResponse200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | [**InlineResponse200Message**](InlineResponse200Message.md) |  | 
**error** | [**Error**](Error.md) |  | [optional] 
