# OndcProtocolApiForRetailGroceryFb.OnTrackMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tracking** | [**Tracking**](Tracking.md) |  | 
