# OndcProtocolApiForRetailGroceryFb.FeedbackUrl

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **String** | feedback URL sent by the Seller App | [optional] 
**tlMethod** | **String** |  | [optional] 
**params** | [**FeedbackUrlParams**](FeedbackUrlParams.md) |  | [optional] 

<a name="TlMethodEnum"></a>
## Enum: TlMethodEnum

* `get` (value: `"http/get"`)
* `post` (value: `"http/post"`)

