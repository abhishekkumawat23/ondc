# OndcProtocolApiForRetailGroceryFb.SupportBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**context** | [**Context**](Context.md) |  | 
**message** | [**SupportMessage**](SupportMessage.md) |  | 
