# OndcProtocolApiForRetailGroceryFb.Tracking

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **String** |  | [optional] 
**status** | **String** |  | [optional] 

<a name="StatusEnum"></a>
## Enum: StatusEnum

* `active` (value: `"active"`)
* `inactive` (value: `"inactive"`)

