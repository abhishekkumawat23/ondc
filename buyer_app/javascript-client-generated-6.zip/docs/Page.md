# OndcProtocolApiForRetailGroceryFb.Page

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | [optional] 
**nextId** | **String** |  | [optional] 
