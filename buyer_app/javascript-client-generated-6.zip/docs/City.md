# OndcProtocolApiForRetailGroceryFb.City

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Name of the city | [optional] 
**code** | [**CityCode**](CityCode.md) |  | [optional] 
