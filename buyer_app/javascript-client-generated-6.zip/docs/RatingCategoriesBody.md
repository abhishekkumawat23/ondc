# OndcProtocolApiForRetailGroceryFb.RatingCategoriesBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**context** | [**Context**](Context.md) |  | [optional] 
**ratingCategories** | [**[RatingCategory]**](RatingCategory.md) |  | [optional] 
