# OndcProtocolApiForRetailGroceryFb.Offer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**OfferId**](OfferId.md) |  | [optional] 
**descriptor** | [**Descriptor**](Descriptor.md) |  | [optional] 
**locationIds** | [**[LocationId]**](LocationId.md) |  | [optional] 
**categoryIds** | [**[CategoryId]**](CategoryId.md) |  | [optional] 
**itemIds** | [**[ItemId]**](ItemId.md) |  | [optional] 
**time** | [**Time**](Time.md) |  | [optional] 
