# OndcProtocolApiForRetailGroceryFb.OnSelectMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**order** | [**OnSelectMessageOrder**](OnSelectMessageOrder.md) |  | 
