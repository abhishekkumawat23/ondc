# OndcProtocolApiForRetailGroceryFb.GetRatingCategoriesBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**context** | [**Context**](Context.md) |  | [optional] 
