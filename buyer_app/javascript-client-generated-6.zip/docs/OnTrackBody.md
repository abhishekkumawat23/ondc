# OndcProtocolApiForRetailGroceryFb.OnTrackBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**context** | [**Context**](Context.md) |  | 
**message** | [**OnTrackMessage**](OnTrackMessage.md) |  | [optional] 
**error** | [**Error**](Error.md) |  | [optional] 
