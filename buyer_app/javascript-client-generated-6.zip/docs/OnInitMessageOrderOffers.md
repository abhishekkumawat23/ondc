# OndcProtocolApiForRetailGroceryFb.OnInitMessageOrderOffers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**OfferId**](OfferId.md) |  | [optional] 
