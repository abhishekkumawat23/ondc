# OndcProtocolApiForRetailGroceryFb.Location

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**LocationId**](LocationId.md) |  | [optional] 
**descriptor** | [**Descriptor**](Descriptor.md) |  | [optional] 
**gps** | [**Gps**](Gps.md) |  | [optional] 
**address** | [**Address**](Address.md) |  | [optional] 
**stationCode** | **String** |  | [optional] 
**city** | [**City**](City.md) |  | [optional] 
**country** | [**Country**](Country.md) |  | [optional] 
**circle** | [**Circle**](Circle.md) |  | [optional] 
**polygon** | **String** |  | [optional] 
**_3dspace** | **String** |  | [optional] 
**time** | [**Time**](Time.md) |  | [optional] 
