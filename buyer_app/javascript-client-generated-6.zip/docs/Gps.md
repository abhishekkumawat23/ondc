# OndcProtocolApiForRetailGroceryFb.Gps

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
