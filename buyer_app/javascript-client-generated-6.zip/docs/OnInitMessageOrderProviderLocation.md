# OndcProtocolApiForRetailGroceryFb.OnInitMessageOrderProviderLocation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**LocationId**](LocationId.md) |  | [optional] 
