# OndcProtocolApiForRetailGroceryFb.OnInitMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**order** | [**OnInitMessageOrder**](OnInitMessageOrder.md) |  | 
