# OndcProtocolApiForRetailGroceryFb.StatusBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**context** | [**Context**](Context.md) |  | 
**message** | [**StatusMessage**](StatusMessage.md) |  | 
