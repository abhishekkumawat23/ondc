# OndcProtocolApiForRetailGroceryFb.CategoryId

## Enum

* `grocery` (value: `"Grocery"`)
* `packagedCommodities` (value: `"Packaged Commodities"`)
* `packagedFoods` (value: `"Packaged Foods"`)
* `fruitsAndVegetables` (value: `"Fruits and Vegetables"`)
* `FB` (value: `"F&B"`)
* `fashion` (value: `"Fashion"`)
