# OndcProtocolApiForRetailGroceryFb.Language

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** |  | [optional] 
