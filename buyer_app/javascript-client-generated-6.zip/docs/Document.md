# OndcProtocolApiForRetailGroceryFb.Document

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **String** |  | [optional] 
**label** | **String** |  | [optional] 
