# OndcProtocolApiForRetailGroceryFb.Currency

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
