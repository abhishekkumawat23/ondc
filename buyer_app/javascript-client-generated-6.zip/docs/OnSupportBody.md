# OndcProtocolApiForRetailGroceryFb.OnSupportBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**context** | [**Context**](Context.md) |  | 
**message** | [**OnSupportMessage**](OnSupportMessage.md) |  | [optional] 
**error** | [**Error**](Error.md) |  | [optional] 
