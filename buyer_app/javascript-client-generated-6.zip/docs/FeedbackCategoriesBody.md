# OndcProtocolApiForRetailGroceryFb.FeedbackCategoriesBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**context** | [**Context**](Context.md) |  | [optional] 
**feedbackCategories** | [**[RatingCategory]**](RatingCategory.md) |  | [optional] 
