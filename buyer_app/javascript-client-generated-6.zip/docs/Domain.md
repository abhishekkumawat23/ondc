# OndcProtocolApiForRetailGroceryFb.Domain

## Enum

* `nic200452110` (value: `"nic2004:52110"`)
