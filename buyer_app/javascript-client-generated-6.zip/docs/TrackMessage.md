# OndcProtocolApiForRetailGroceryFb.TrackMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderId** | [**OrderId**](OrderId.md) |  | 
**callbackUrl** | **String** |  | [optional] 
