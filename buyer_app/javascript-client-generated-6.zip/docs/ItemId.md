# OndcProtocolApiForRetailGroceryFb.ItemId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
