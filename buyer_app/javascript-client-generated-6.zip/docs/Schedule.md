# OndcProtocolApiForRetailGroceryFb.Schedule

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**frequency** | [**Duration**](Duration.md) |  | [optional] 
**holidays** | **[Date]** |  | [optional] 
**times** | **[Date]** |  | [optional] 
