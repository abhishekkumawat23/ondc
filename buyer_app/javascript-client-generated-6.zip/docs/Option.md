# OndcProtocolApiForRetailGroceryFb.Option

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**OptionId**](OptionId.md) |  | [optional] 
**descriptor** | [**Descriptor**](Descriptor.md) |  | [optional] 
