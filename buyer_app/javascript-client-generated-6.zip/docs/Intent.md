# OndcProtocolApiForRetailGroceryFb.Intent

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**descriptor** | [**Descriptor**](Descriptor.md) |  | [optional] 
**provider** | [**Provider**](Provider.md) |  | [optional] 
**fulfillment** | [**Fulfillment**](Fulfillment.md) |  | [optional] 
**payment** | [**Payment**](Payment.md) |  | [optional] 
**category** | [**Category**](Category.md) |  | [optional] 
**offer** | [**Offer**](Offer.md) |  | [optional] 
**item** | [**Item**](Item.md) |  | [optional] 
**tags** | [**Tags**](Tags.md) |  | [optional] 
