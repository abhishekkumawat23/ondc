# OndcProtocolApiForRetailGroceryFb.PaymentParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
