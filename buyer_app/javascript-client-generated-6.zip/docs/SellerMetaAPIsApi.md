# OndcProtocolApiForRetailGroceryFb.SellerMetaAPIsApi

All URIs are relative to *http://localhost:9060/ONDC/ONDC-Protocol-Hyperlocal/1.0.13*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getFeedbackCategoriesPOST**](SellerMetaAPIsApi.md#getFeedbackCategoriesPOST) | **POST** /get_feedback_categories | 

<a name="getFeedbackCategoriesPOST"></a>
# **getFeedbackCategoriesPOST**
> InlineResponse200 getFeedbackCategoriesPOST(opts)



Get a list of categories for which feedback can be given by the Buyer App

### Example
```javascript
import {OndcProtocolApiForRetailGroceryFb} from 'ondc_protocol_api_for_retail__grocery_fb';
let defaultClient = OndcProtocolApiForRetailGroceryFb.ApiClient.instance;

// Configure API key authorization: GatewaySubscriberAuth
let GatewaySubscriberAuth = defaultClient.authentications['GatewaySubscriberAuth'];
GatewaySubscriberAuth.apiKey = 'YOUR API KEY';
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//GatewaySubscriberAuth.apiKeyPrefix = 'Token';

// Configure API key authorization: GatewaySubscriberAuthNew
let GatewaySubscriberAuthNew = defaultClient.authentications['GatewaySubscriberAuthNew'];
GatewaySubscriberAuthNew.apiKey = 'YOUR API KEY';
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//GatewaySubscriberAuthNew.apiKeyPrefix = 'Token';

// Configure API key authorization: SubscriberAuth
let SubscriberAuth = defaultClient.authentications['SubscriberAuth'];
SubscriberAuth.apiKey = 'YOUR API KEY';
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//SubscriberAuth.apiKeyPrefix = 'Token';

let apiInstance = new OndcProtocolApiForRetailGroceryFb.SellerMetaAPIsApi();
let opts = { 
  'body': new OndcProtocolApiForRetailGroceryFb.GetFeedbackCategoriesBody() // GetFeedbackCategoriesBody | Context header is sent as the request
};
apiInstance.getFeedbackCategoriesPOST(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**GetFeedbackCategoriesBody**](GetFeedbackCategoriesBody.md)| Context header is sent as the request | [optional] 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

[GatewaySubscriberAuth](../README.md#GatewaySubscriberAuth), [GatewaySubscriberAuthNew](../README.md#GatewaySubscriberAuthNew), [SubscriberAuth](../README.md#SubscriberAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

