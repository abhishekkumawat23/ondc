# OndcProtocolApiForRetailGroceryFb.ProviderId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
