# OndcProtocolApiForRetailGroceryFb.Country

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Name of the country | [optional] 
**code** | [**CountryCode**](CountryCode.md) |  | [optional] 
