# OndcProtocolApiForRetailGroceryFb.OrderId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
