# OndcProtocolApiForRetailGroceryFb.UpdateBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**context** | [**Context**](Context.md) |  | 
**message** | [**UpdateMessage**](UpdateMessage.md) |  | 
