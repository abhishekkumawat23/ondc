# OndcProtocolApiForRetailGroceryFb.SearchBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**context** | [**Context**](Context.md) |  | 
**message** | [**SearchMessage**](SearchMessage.md) |  | 
