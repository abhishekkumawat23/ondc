# OndcProtocolApiForRetailGroceryFb.ItemQuantityAllocated

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **Number** |  | [optional] 
**measure** | [**Scalar**](Scalar.md) |  | [optional] 
