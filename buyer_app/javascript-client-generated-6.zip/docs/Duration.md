# OndcProtocolApiForRetailGroceryFb.Duration

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
