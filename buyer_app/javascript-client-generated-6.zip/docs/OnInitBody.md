# OndcProtocolApiForRetailGroceryFb.OnInitBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**context** | [**Context**](Context.md) |  | 
**message** | [**OnInitMessage**](OnInitMessage.md) |  | [optional] 
**error** | [**Error**](Error.md) |  | [optional] 
