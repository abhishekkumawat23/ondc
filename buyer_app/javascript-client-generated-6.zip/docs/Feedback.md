# OndcProtocolApiForRetailGroceryFb.Feedback

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**feedbackForm** | [**FeedbackForm**](FeedbackForm.md) |  | [optional] 
**feedbackUrl** | [**FeedbackUrl**](FeedbackUrl.md) |  | [optional] 
