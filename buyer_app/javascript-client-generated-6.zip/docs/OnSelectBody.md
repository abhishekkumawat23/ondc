# OndcProtocolApiForRetailGroceryFb.OnSelectBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**context** | [**Context**](Context.md) |  | 
**message** | [**OnSelectMessage**](OnSelectMessage.md) |  | [optional] 
**error** | [**Error**](Error.md) |  | [optional] 
