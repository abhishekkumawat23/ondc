# OndcProtocolApiForRetailGroceryFb.OrderProvider

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**ProviderId**](ProviderId.md) |  | [optional] 
**locations** | [**[OrderProviderLocations]**](OrderProviderLocations.md) |  | [optional] 
