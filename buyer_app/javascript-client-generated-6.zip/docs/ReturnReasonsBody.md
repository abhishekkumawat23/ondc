# OndcProtocolApiForRetailGroceryFb.ReturnReasonsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**context** | [**Context**](Context.md) |  | [optional] 
**returnReasons** | [**[Option]**](Option.md) |  | [optional] 
