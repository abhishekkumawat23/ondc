# OndcProtocolApiForRetailGroceryFb.Scalar

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  | [optional] 
**value** | **Number** |  | 
**estimatedValue** | **Number** |  | [optional] 
**computedValue** | **Number** |  | [optional] 
**range** | [**ScalarRange**](ScalarRange.md) |  | [optional] 
**unit** | **String** |  | 

<a name="TypeEnum"></a>
## Enum: TypeEnum

* `CONSTANT` (value: `"CONSTANT"`)
* `VARIABLE` (value: `"VARIABLE"`)

