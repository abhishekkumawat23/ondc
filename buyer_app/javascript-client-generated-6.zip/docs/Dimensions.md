# OndcProtocolApiForRetailGroceryFb.Dimensions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**length** | [**Scalar**](Scalar.md) |  | [optional] 
**breadth** | [**Scalar**](Scalar.md) |  | [optional] 
**height** | [**Scalar**](Scalar.md) |  | [optional] 
