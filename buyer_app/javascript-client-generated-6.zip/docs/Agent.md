# OndcProtocolApiForRetailGroceryFb.Agent

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**phone** | **String** |  | [optional] 
**email** | **String** |  | [optional] 
**tags** | [**Tags**](Tags.md) |  | [optional] 
**rateable** | [**Rateable**](Rateable.md) |  | [optional] 
