# OndcProtocolApiForRetailGroceryFb.TrackingData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
