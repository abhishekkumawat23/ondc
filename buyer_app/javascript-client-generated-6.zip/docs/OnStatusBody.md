# OndcProtocolApiForRetailGroceryFb.OnStatusBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**context** | [**Context**](Context.md) |  | 
**message** | [**SelectMessage**](SelectMessage.md) |  | [optional] 
**error** | [**Error**](Error.md) |  | [optional] 
