# OndcProtocolApiForRetailGroceryFb.FeedbackFormElementId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
