# OndcProtocolApiForRetailGroceryFb.OrderItems

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**ItemId**](ItemId.md) |  | 
**quantity** | [**ItemQuantitypropertiesselected**](ItemQuantitypropertiesselected.md) |  | [optional] 
