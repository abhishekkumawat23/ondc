# OndcProtocolApiForRetailGroceryFb.CountryCode

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
