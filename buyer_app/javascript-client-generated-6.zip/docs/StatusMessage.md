# OndcProtocolApiForRetailGroceryFb.StatusMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderId** | [**OrderId**](OrderId.md) |  | 
