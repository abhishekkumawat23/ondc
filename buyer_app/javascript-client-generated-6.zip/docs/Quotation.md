# OndcProtocolApiForRetailGroceryFb.Quotation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**price** | [**Price**](Price.md) |  | 
**breakup** | [**[QuotationBreakup]**](QuotationBreakup.md) |  | [optional] 
**ttl** | [**Duration**](Duration.md) |  | [optional] 
