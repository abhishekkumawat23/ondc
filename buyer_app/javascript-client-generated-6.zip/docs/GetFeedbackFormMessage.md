# OndcProtocolApiForRetailGroceryFb.GetFeedbackFormMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ratingValue** | [**RatingValue**](RatingValue.md) |  | [optional] 
**ratingCategory** | [**RatingCategory**](RatingCategory.md) |  | [optional] 
