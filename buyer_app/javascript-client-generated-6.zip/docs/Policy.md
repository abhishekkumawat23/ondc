# OndcProtocolApiForRetailGroceryFb.Policy

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**PolicyId**](PolicyId.md) |  | [optional] 
**descriptor** | [**Descriptor**](Descriptor.md) |  | [optional] 
**parentPolicyId** | [**PolicyId**](PolicyId.md) |  | [optional] 
**time** | [**Time**](Time.md) |  | [optional] 
