# OndcProtocolApiForRetailGroceryFb.Support

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  | [optional] 
**refId** | **String** |  | [optional] 
**channels** | [**Tags**](Tags.md) |  | [optional] 

<a name="TypeEnum"></a>
## Enum: TypeEnum

* `order` (value: `"order"`)
* `billing` (value: `"billing"`)
* `fulfillment` (value: `"fulfillment"`)

