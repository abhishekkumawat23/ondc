# OndcProtocolApiForRetailGroceryFb.OnSearchMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**catalog** | [**Catalog**](Catalog.md) |  | 
