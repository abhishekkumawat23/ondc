# OndcProtocolApiForRetailGroceryFb.CityCode

## Enum

* `_080` (value: `"std:080"`)
* `_011` (value: `"std:011"`)
* `_0422` (value: `"std:0422"`)
* `_0364` (value: `"std:0364"`)
* `_0522` (value: `"std:0522"`)
* `_0755` (value: `"std:0755"`)
* `_044` (value: `"std:044"`)
* `_022` (value: `"std:022"`)
* `_020` (value: `"std:020"`)
* `_040` (value: `"std:040"`)
* `_0145` (value: `"std:0145"`)
