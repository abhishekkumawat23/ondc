# OndcProtocolApiForRetailGroceryFb.Time

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**label** | **String** |  | [optional] 
**timestamp** | **Date** |  | [optional] 
**duration** | [**Duration**](Duration.md) |  | [optional] 
**range** | [**TimeRange**](TimeRange.md) |  | [optional] 
**days** | **String** | comma separated values representing days of the week | [optional] 
**schedule** | [**Schedule**](Schedule.md) |  | [optional] 
