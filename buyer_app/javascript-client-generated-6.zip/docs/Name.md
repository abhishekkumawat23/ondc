# OndcProtocolApiForRetailGroceryFb.Name

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
