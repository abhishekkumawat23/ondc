# OndcProtocolApiForRetailGroceryFb.Vehicle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**category** | **String** |  | [optional] 
**capacity** | **Number** |  | [optional] 
**make** | **String** |  | [optional] 
**model** | **String** |  | [optional] 
**size** | **String** |  | [optional] 
**variant** | **String** |  | [optional] 
**color** | **String** |  | [optional] 
**energyType** | **String** |  | [optional] 
**registration** | **String** |  | [optional] 
